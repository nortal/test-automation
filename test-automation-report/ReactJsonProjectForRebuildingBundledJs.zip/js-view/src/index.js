import React from 'react';
import ReactDOM from 'react-dom';
import ReactJson from "react-json-view";

document.querySelectorAll('.content')
    .forEach(element => {
        element.onclick = function () {
            const domContainer = element.getElementsByClassName('json-view')[0];
            const response = JSON.parse(atob(domContainer.getAttribute('data-input-json')));
            ReactDOM.render(React.createElement(ReactJson, {src: response, theme: 'monokai', iconStyle : 'circle', displayDataTypes : false, collapseStringsAfterLength : 50}), domContainer);
        }
    });
